package domain

import generalutil.getListOfFiles
import models.{Trading, TradingVolume}

import java.io.File
import scala.util.Try

object MaxProfit extends App{

  val files = getListOfFiles(new File("/Users/jenniferliu/Downloads/test_data/"))

  val sourceData = files.filter(_.getName.startsWith("x")).flatMap {f =>
    val bufferedSource = io.Source.fromFile(f)
    val tradingList = bufferedSource.getLines().map{l =>
      val columns = l.split('\t')
      // todo: type class
      Trading(columns(0), columns(1), columns(2),columns(3),
        Try(columns(4).toInt).toOption, Try(BigDecimal(columns(5))).toOption)
    }
    val tradingVolumeList = tradingList.map{ t =>
      TradingVolume(t.date, t.counterParty, t.tick, t.buySell,
      for {
        price <- t.price
        shares <- t.shares
      } yield price * shares)
    }.toList
    bufferedSource.close()
    tradingVolumeList
  }

  val max = sourceData.groupBy(_.tick).map {
    case (tick, tradingVolumeList) =>
      val (buy, sell) = tradingVolumeList.partition(_.buySell == "BUY")
      val buyVolume = buy.flatMap(_.volume.toList).sum
      val sellVolume = sell.flatMap(_.volume.toList).sum

     // tradingVolumeList.map(x => if(x.buySell == "BUY") x.volume.map(_ * -1) else x.volume)
      //  .flatMap(_.toList).sum

      (tick, sellVolume - buyVolume)
  }.maxBy(_._2)

  println(max)




}
