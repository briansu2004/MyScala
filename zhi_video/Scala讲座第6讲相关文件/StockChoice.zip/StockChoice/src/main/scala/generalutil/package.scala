import java.io.File

package object generalutil {
  def getListOfFiles(dir: File):List[File] = dir.listFiles.filter(_.isFile).toList
}
