package object models {
  case class Trading(date: String, counterParty: String, tick: String,
                     buySell: String, shares: Option[Int], price: Option[BigDecimal] )
  case class TradingVolume(date: String, counterParty: String, tick: String,
                           buySell: String, volume: Option[BigDecimal])
}
