package org.wzhi.domain

import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers._
import org.wzhi.domain.Models.Trade
import org.wzhi.domain.Readers._
import org.wzhi.tools.time.implicits._

class ReadersTest extends AnyFlatSpec {
  "readMarket" should "parse string value" in {
    readMarket("AAPL 351.11").readData.toList.head shouldBe ("AAPL", BigDecimal(351.11))
  }

  "readMarket" should "avoid invalid string value" in {
    readMarket("AAPL sdfs").readData.isEmpty shouldBe true
    readMarket("2132 sdfs").readData.isEmpty shouldBe true
    readMarket("some garbage").readData.isEmpty shouldBe true
    readMarket("").readData.isEmpty shouldBe true
  }

  "readTrades" should "parse string as trade value" in {
    readTrades("2011-03-09\tViking Global Investors\tINTC\tSELL\t47300\t21.24").readData.
      toList.head shouldBe Trade("2011-03-09".dateValue, "Viking Global Investors", "INTC", false, 47300L, BigDecimal(21.24))

    readTrades("2011-03-09\tViking Global Investors\tINTC\tBUY\t47300\t21.24").readData.
      toList.head shouldBe Trade("2011-03-09".dateValue, "Viking Global Investors", "INTC", true, 47300L, BigDecimal(21.24))

    readTrades("2011/03/09 \tViking Global Investors \tINTC\tBUY \t 47300\t 21.24 ").readData.
      toList.head shouldBe Trade("2011-03-09".dateValue, "Viking Global Investors", "INTC", true, 47300L, BigDecimal(21.24))

    readTrades("2011/03/09 \tViking Global Investors \tINTC\tBUY \t 47300\t 21.24 \t").readData.
      toList.head shouldBe Trade("2011-03-09".dateValue, "Viking Global Investors", "INTC", true, 47300L, BigDecimal(21.24))
  }

  "readTrades" should "avoid invalid string value" in {
    readTrades("2011-03-09\tViking Global Investors\tINTC\tSELL\t47300\t").readData.isEmpty shouldBe true

    readTrades("xxxx\tViking Global Investors\tINTC\tSELL\t47300\t21.24").readData.isEmpty shouldBe true

    readTrades("2011-03-09\t\t\tSELL\t47300\t21.24").readData.isEmpty shouldBe true

    readTrades("").readData.isEmpty shouldBe true
  }
}
