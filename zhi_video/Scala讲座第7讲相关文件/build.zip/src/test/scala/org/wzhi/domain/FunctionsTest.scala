package org.wzhi.domain

import org.scalatest.matchers.should.Matchers._
import org.wzhi.domain.Functions.maxProfit
import org.wzhi.domain.Models.Trade
import org.wzhi.tools.time.implicits._

class FunctionsTest extends org.scalatest.flatspec.AnyFlatSpec {
  "maxProfit" should "successfully get max profit from list of trades" in {
    val trades = List(
      Trade("2021-02-01".dateValue, "Morgan", "AAPL", true, 10L, BigDecimal(351.23)),
      Trade("2021-02-01".dateValue, "Morgan", "AAPL", false, 10L, BigDecimal(351.23)),
    )
    maxProfit(trades.iterator, Map()) shouldBe ("AAPL", 0.0)

    val trades2 = trades ++ List(
      Trade("2021-02-01".dateValue, "Morgan", "TSLA", true, 10L, BigDecimal(1000)),
      Trade("2021-02-01".dateValue, "Morgan", "TSLA", false, 10L, BigDecimal(2000))
    )
    maxProfit(trades2.iterator, Map()) shouldBe ("TSLA", 10000)

    val trades3 = trades ++ List(
      Trade("2021-02-01".dateValue, "Morgan", "TSLA", true, 10L, BigDecimal(1000)),
      Trade("2021-02-01".dateValue, "Morgan", "TSLA", false, 9L, BigDecimal(2000))
    )
    maxProfit(trades3.iterator, Map("TSLA" -> BigDecimal(2000))) shouldBe ("TSLA", 10000)

    maxProfit(trades3.iterator, Map("TSLA" -> BigDecimal(1000))) shouldBe ("TSLA", 9000)

    the [RuntimeException] thrownBy maxProfit(trades3.iterator, Map()) should have message "Cannot find TSLA current market value"
  }
}
