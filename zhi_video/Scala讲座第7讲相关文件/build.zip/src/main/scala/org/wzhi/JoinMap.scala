package org.wzhi

object JoinMap extends App {

  val map1 = Map(1 -> "a", 2 -> "b")
  val map2 = Map(2 -> "c", 3 -> "d")
  import cats.implicits._
  map1 |+| map2

  println(map2 ++ map1.map{case(k,v) => map2.get(k) match {
    case None => k -> v
    case Some(x) => k -> (x + v)
  }})
}
