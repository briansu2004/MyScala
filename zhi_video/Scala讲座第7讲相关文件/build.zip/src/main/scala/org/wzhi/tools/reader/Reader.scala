package org.wzhi.tools.reader

trait Reader[+A] {
  def readData: Iterator[A]
}