package org.wzhi.domain

import org.joda.time.DateTime

object Models {
  case class Trade(date: DateTime, counterParty: String, tick: String, buy: Boolean, shares: Long, price: BigDecimal)
}
