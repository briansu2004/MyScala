package org.wzhi.domain

import org.wzhi.domain.Models.Trade

import cats.implicits._

object Functions {
  def maxProfit(trades: Iterator[Trade], current: Map[String, BigDecimal]): (String, BigDecimal) =
    trades.toList.groupBy(_.tick).map {
      case (tick, tradeList) =>
        val (buy, sell) = tradeList.partition(_.buy)
        val tradingProfit = sell.map(x => x.price * x.shares).sum - buy.map(x => x.price * x.shares).sum
        val holdingShares = buy.map(_.shares).sum - sell.map(_.shares).sum
        val profit =
          if(holdingShares == 0) {
            tradingProfit
          } else current.get(tick).map(x => (x * holdingShares)) match {
            case Some(value) => value + tradingProfit
            case _ => throw new RuntimeException(s"Cannot find ${tick} current market value")
          }
        tick -> profit
    }.maxBy(_._2)
}
