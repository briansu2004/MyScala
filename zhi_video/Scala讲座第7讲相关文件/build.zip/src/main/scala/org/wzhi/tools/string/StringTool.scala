package org.wzhi.tools.string

import scala.util.Try

trait StringTool {
  def value: String
  def partitionByLastOf(char: Char): (String, String) = {
    val strLen: Int = value.length()
    value.lastIndexOf(char) match {
      case -1 => (value, "")
      case index => (value.substring(0, index), value.substring(index + 1, strLen))
    }
  }
  def getOrElse(str: String): String = if(value.isEmpty) str else value
  def toBigDecimalOption: Option[BigDecimal] = Try(BigDecimal(value)).toOption
  def toOption: Option[String] = if(value.isEmpty) None else Option(value)
}
