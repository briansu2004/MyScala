package org.wzhi.tools

package object string {
  object implicits {
    implicit def strWithTools(str: String): StringTool = new StringTool{def value: String = str}
  }
}
