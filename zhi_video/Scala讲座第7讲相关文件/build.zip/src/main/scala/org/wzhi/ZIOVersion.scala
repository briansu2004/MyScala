package org.wzhi

import org.wzhi.domain.Models.Trade
import org.wzhi.domain.Readers.readTrades
import org.wzhi.infra.FileTools.readFilesInDir
import zio._
import zio.stream.{ZSink, ZStream, ZTransducer}

import java.io.{BufferedReader, File}
import java.nio.file.Files
import scala.io.{BufferedSource, Source}


//
//object ZIOVersion extends App {
//  val fileIter = readFilesInDir("""C:\code\testfiles\x*""").readData
//  val test = for {
//    file <- ZStream.fromIterator(fileIter)
//    line <- ZStream.fromFile(file.toPath).transduce(ZTransducer.utf8Decode >>> ZTransducer.splitLines)
//    trading <- ZStream.fromIterator(readTrades(line).readData)
//  } yield {
//    trading
//  }
//
//  test.fold(Map.empty[String, Trade]){case (map, next) =>map.get(next.tick) match {
//    case None => map ++ next.tick -> next
//    case Some(n) => ???
//  } }
//  override def run(args: List[String]): URIO[zio.ZEnv, ExitCode] = test.run(ZSink.drain).exitCode
//}
