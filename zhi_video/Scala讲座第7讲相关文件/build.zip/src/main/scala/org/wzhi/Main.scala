package org.wzhi

object Main extends App {
  import org.wzhi.infra.FileTools._
  import tools.implicits._
  import tools.reader.implicits._
  import domain.Readers._
  import domain.Models._
  import org.wzhi.domain.Functions.maxProfit

  val readTradesFromDir = readFilesInDir >>>> readCsvFile >>>> readTrades
  val readMarketFromDir = readFilesInDir >>>> readCsvFile >>>> readMarket

  val trades: Iterator[Trade] = readTradesFromDir.run("""C:\code\testfiles\x*""").readData
  val market: Map[String, BigDecimal] = readMarketFromDir.run("""C:\code\testfiles\m*""").readData.toMap

  println(maxProfit(trades, market))
}
