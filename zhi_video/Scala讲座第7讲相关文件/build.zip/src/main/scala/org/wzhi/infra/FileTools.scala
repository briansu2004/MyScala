package org.wzhi.infra

import org.wzhi.tools.reader.Reader
import org.wzhi.tools.string.implicits.strWithTools

import java.io.File
import scala.io.Source

object FileTools {
  val readFilesInDir: String => Reader[File] = uri => new Reader[File] {
    override def readData: Iterator[File] = {
      val (dirPath, matcher) = uri.replace('\\', '/').partitionByLastOf('/')
      val dir = new File(dirPath)
      dir.listFiles.iterator.filter(_.isFile).filter{ f =>
        if(matcher.endsWith("*")) {
          f.getName.startsWith(matcher.dropRight(1))
        }
        else if(matcher.startsWith("*")) {
        f.getName.endsWith(matcher.drop(1))
        }
        else if(matcher.isEmpty) true
        else f.getName == matcher
      }.iterator
    }
  }

  val readCsvFile: File => Reader[String] = file => new Reader[String] {
    override def readData: Iterator[String] = {
      val buffer = Source.fromFile(file)
      val iterator = buffer.getLines().toList.iterator
      buffer.close()
      iterator
    }
  }

  val readCsvFileWithHeader: File => Reader[String] = file => new Reader[String] {
    override def readData: Iterator[String] = {
      val buffer = Source.fromFile(file)
      val iterator = buffer.getLines().drop(1).toList.iterator
      buffer.close()
      iterator
    }
  }
}
