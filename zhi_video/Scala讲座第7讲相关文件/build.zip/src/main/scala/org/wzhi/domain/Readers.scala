package org.wzhi.domain

import org.wzhi.tools.reader.Reader
import org.wzhi.tools.string.implicits.strWithTools
import cats.implicits._
import org.wzhi.domain.Models.Trade
import org.wzhi.tools.time.implicits.StringDateTime

object Readers {
  val readMarket: String => Reader[(String, BigDecimal)] = line => new Reader[(String, BigDecimal)] {
    override def readData: Iterator[(String, BigDecimal)] = (line.split(' ').map(_.trim) match {
      case columns if columns.length == 2 =>
        (columns(0).toOption, columns(1).toBigDecimalOption) mapN (_ -> _)
      case _ => None
    }).iterator
  }

  val readTrades: String => Reader[Trade] = line => new Reader[Trade] {
    override def readData: Iterator[Trade] = (line.split('\t').map(_.trim) match {
      case columns if columns.length == 6 =>
        (columns(0).dateValueOption,
          columns(1).toOption,
          columns(2).toOption,
          Option(columns(3).toUpperCase == "BUY"),
          columns(4).toLongOption,
          columns(5).toBigDecimalOption
        ) mapN Trade
      case _ => None
    }).iterator
  }
}
