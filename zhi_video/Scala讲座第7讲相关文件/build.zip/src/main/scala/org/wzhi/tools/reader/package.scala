package org.wzhi.tools

package object reader {
  object implicits {
    import cats.FlatMap

    implicit val readerMonad = new FlatMap[Reader] {
      override def flatMap[A, B](fa: Reader[A])(f: A => Reader[B]): Reader[B] =
        new Reader[B] {
          def readData: Iterator[B] = fa.readData.flatMap(f(_).readData)
        }

      override def tailRecM[A, B](a: A)(f: A => Reader[Either[A, B]]): Reader[B] =
        new Reader[B] {
          def readData: Iterator[B] = f(a).readData.flatMap {
            case Left(_) => Iterator.empty[B]
            case Right(b) => Iterator(b)
          }
        }

      override def map[A, B](fa: Reader[A])(f: A => B): Reader[B] = new Reader[B] {
        override def readData: Iterator[B] = fa.readData.map(f)
      }
    }
  }
}
