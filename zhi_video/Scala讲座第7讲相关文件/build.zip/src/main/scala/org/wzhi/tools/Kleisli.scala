package org.wzhi.tools

import cats.FlatMap
import cats.implicits._

final case class Kleisli[F[_], A, B](run: A => F[B]) {
  def >>>> [Z](k: Kleisli[F, B, Z])(implicit F: FlatMap[F]): Kleisli[F, A, Z] =
    Kleisli[F, A, Z](a => run(a).flatMap(k.run))
}


