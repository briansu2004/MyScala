package org.wzhi

import org.wzhi.tools.reader.Reader

package object tools {
  object implicits {
    implicit def arrow[F[_], A, B](run: A => F[B]): Kleisli[F, A, B] = Kleisli(run)
  }
}
